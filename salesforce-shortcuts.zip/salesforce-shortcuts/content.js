// Salesforce Contact Shortcuts Extension
(function() {
  'use strict';

  const EXT_NAME = 'SF Shortcuts';
  const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
  
  // Logging utilities
  function log(message, type = 'info') {
    const prefix = `[${EXT_NAME}]`;
    const styles = {
      info: 'color: #2196F3',
      success: 'color: #4CAF50',
      warning: 'color: #FF9800',
      error: 'color: #F44336'
    };
    console[type === 'error' ? 'error' : 'log'](`%c${prefix} ${message}`, styles[type]);
  }

  // Check if element is visible
  function isVisible(element) {
    if (!element) return false;
    const rect = element.getBoundingClientRect();
    const style = window.getComputedStyle(element);
    return rect.width > 0 && rect.height > 0 && 
           style.visibility !== 'hidden' && style.display !== 'none';
  }

  // Find element by text content
  function findByText(tag, text, index = 0) {
    const elements = [...document.querySelectorAll(tag)].filter(el => {
      const elText = el.textContent.trim().toLowerCase();
      return elText.includes(text.toLowerCase()) && isVisible(el);
    });
    
    if (elements.length === 0) {
      return null;
    }
    
    if (elements.length > 1) {
      log(`Found ${elements.length} elements matching "${text}" - using index ${index}`);
    }
    
    return elements[index] || null;
  }

  // Find element with retry logic
  function findElement(finder, description, maxAttempts = 10, interval = 500) {
    return new Promise((resolve, reject) => {
      let attempts = 0;
      
      function tryFind() {
        attempts++;
        const element = finder();
        
        if (element && isVisible(element)) {
          log(`✓ Found "${description}"`, 'success');
          resolve(element);
          return;
        }
        
        if (attempts >= maxAttempts) {
          const error = `Could not find "${description}" after ${maxAttempts} attempts`;
          log(error, 'error');
          reject(new Error(error));
          return;
        }
        
        setTimeout(tryFind, interval);
      }
      
      tryFind();
    });
  }

  // Show error toast
  function showToast(message) {
    const existingToast = document.getElementById('sf-shortcuts-toast');
    if (existingToast) {
      existingToast.remove();
    }

    const toast = document.createElement('div');
    toast.id = 'sf-shortcuts-toast';
    toast.className = 'sf-shortcuts-toast';
    toast.innerHTML = `
      <div class="sf-shortcuts-toast-content">
        <div class="sf-shortcuts-toast-message">${message}</div>
        <div class="sf-shortcuts-toast-hint">Open console (${isMac ? 'Cmd+Option+J' : 'Ctrl+Shift+J'}) for details</div>
      </div>
    `;
    
    document.body.appendChild(toast);
    
    toast.addEventListener('click', () => toast.remove());
    
    setTimeout(() => {
      if (toast.parentNode) {
        toast.remove();
      }
    }, 5000);
  }

  // Shortcut configuration
  const shortcuts = {
    email: {
      key: 'm',
      withShift: false,
      description: 'Email',
      finder: () => {
        // Try specific attributes first (most reliable)
        const byValue = document.querySelector('button[value="SendEmail"]');
        if (byValue && isVisible(byValue)) return byValue;
        
        const byAriaLabel = document.querySelector('button[aria-label="Email"]');
        if (byAriaLabel && isVisible(byAriaLabel)) return byAriaLabel;
        
        // Fall back to text search within activity composer area
        const activityButtons = document.querySelectorAll('.slds-button_neutral');
        for (const btn of activityButtons) {
          if (btn.textContent.trim().toLowerCase() === 'email' && isVisible(btn)) {
            return btn;
          }
        }
        
        return null;
      }
    },
    event: {
      key: 'e',
      withShift: false,
      description: 'New Event',
      finder: () => {
        const byValue = document.querySelector('button[value="NewEvent"]');
        if (byValue && isVisible(byValue)) return byValue;
        
        const byAriaLabel = document.querySelector('button[aria-label="New Event"]');
        if (byAriaLabel && isVisible(byAriaLabel)) return byAriaLabel;
        
        return findByText('button', 'New Event', 0);
      }
    },
    task: {
      key: 't',
      withShift: false,
      description: 'New Task',
      finder: () => {
        const byValue = document.querySelector('button[value="NewTask"]');
        if (byValue && isVisible(byValue)) return byValue;
        
        const byAriaLabel = document.querySelector('button[aria-label="New Task"]');
        if (byAriaLabel && isVisible(byAriaLabel)) return byAriaLabel;
        
        return findByText('button', 'New Task', 0);
      }
    },
    call: {
      key: 'c',
      withShift: false,
      description: 'Log a Call',
      finder: () => {
        const byValue = document.querySelector('button[value="LogACall"]');
        if (byValue && isVisible(byValue)) return byValue;
        
        const byAriaLabel = document.querySelector('button[aria-label="Log a Call"]');
        if (byAriaLabel && isVisible(byAriaLabel)) return byAriaLabel;
        
        return findByText('button', 'Log a Call', 0);
      }
    },
    opportunity: {
      key: 'o',
      withShift: false,
      description: 'New Opportunity',
      finder: () => {
        const byName = document.querySelector('button[name="Global.NewOpportunity"]');
        if (byName && isVisible(byName)) return byName;
        
        const byAriaLabel = document.querySelector('button[aria-label="New Opportunity"]');
        if (byAriaLabel && isVisible(byAriaLabel)) return byAriaLabel;
        
        return findByText('button', 'New Opportunity', 0);
      }
    },
    upload: {
      key: 'u',
      withShift: false,
      description: 'Upload Files',
      finder: () => {
        // Find the file input
        const input = document.querySelector('input[type="file"][title*="Upload"]');
        if (input) return input;
        
        // Fall back to finding by text
        const button = findByText('span', 'Upload Files', 0);
        if (button) {
          // Find the associated file input
          const container = button.closest('.slds-file-selector');
          if (container) {
            return container.querySelector('input[type="file"]');
          }
        }
        return null;
      }
    },
    todoList: {
      key: 'l',
      withShift: false,
      description: 'To Do List',
      finder: () => {
        // Find the To Do List utility bar button
        const buttons = [...document.querySelectorAll('.utilityBarButton, button[title*="To Do"]')];
        for (const btn of buttons) {
          if (btn.textContent.includes('To Do List') && isVisible(btn)) {
            return btn;
          }
        }
        return findByText('button', 'To Do List', 0);
      }
    }
  };

  // Check if shortcut matches
  function matchesShortcut(event, keys) {
    const modifierPressed = isMac ? event.ctrlKey : event.altKey;
    if (!modifierPressed) return false;
    
    if (isMac && event.altKey) return false;
    if (!isMac && event.ctrlKey) return false;
    
    if (keys.withShift && !event.shiftKey) return false;
    if (!keys.withShift && event.shiftKey) return false;
    
    return event.key.toLowerCase() === keys.key.toLowerCase();
  }

  // Handle keyboard events
  function handleKeydown(event) {
    // Don't trigger if user is typing in an input
    const target = event.target;
    if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || 
        target.isContentEditable) {
      return;
    }

    for (const [name, config] of Object.entries(shortcuts)) {
      if (matchesShortcut(event, config)) {
        event.preventDefault();
        event.stopPropagation();
        
        log(`Shortcut triggered: ${isMac ? 'Ctrl' : 'Alt'}+${config.key.toUpperCase()} → ${config.description}`);
        
        // Find and click/trigger the element
        const element = config.finder();
        if (element) {
          if (element.tagName === 'INPUT' && element.type === 'file') {
            // For file inputs, trigger the file picker
            element.click();
            log(`✓ Triggered file picker for "${config.description}"`, 'success');
          } else {
            // For buttons, click them
            element.click();
            log(`✓ Clicked "${config.description}"`, 'success');
          }
        } else {
          showToast(`Could not find "${config.description}" button`);
        }
        
        break;
      }
    }
  }

  // Check if we're on a contact page
  function isContactPage() {
    return window.location.pathname.includes('/lightning/r/Contact/');
  }

  // Setup tooltips
  function setupTooltips() {
    chrome.storage.sync.get({ showTooltips: true }, (result) => {
      if (!result.showTooltips) {
        log('Tooltips disabled in settings');
        return;
      }

      log('Setting up tooltips...');
      
      const tooltipDiv = document.createElement('div');
      tooltipDiv.className = 'sf-shortcuts-tooltip';
      tooltipDiv.style.display = 'none';
      document.body.appendChild(tooltipDiv);

      // Initial attachment with delay to let elements load
      setTimeout(() => {
        attachTooltips(tooltipDiv);
      }, 2000);

      // Watch for new elements
      let mutationTimeout;
      const observer = new MutationObserver(() => {
        clearTimeout(mutationTimeout);
        mutationTimeout = setTimeout(() => {
          attachTooltips(tooltipDiv);
        }, 200);
      });

      observer.observe(document.body, { childList: true, subtree: true });
      
      // Periodic check to catch any missed elements
      setInterval(() => {
        attachTooltips(tooltipDiv);
      }, 5000);
    });
  }

  function attachTooltips(tooltipDiv) {
    let attachedCount = 0;
    let alreadyAttachedCount = 0;
    let notFoundCount = 0;
    
    for (const [name, config] of Object.entries(shortcuts)) {
      const element = config.finder();
      
      if (!element) {
        notFoundCount++;
        continue;
      }
      
      if (element.hasAttribute('data-sf-tooltip')) {
        alreadyAttachedCount++;
        continue;
      }
      
      element.setAttribute('data-sf-tooltip', 'true');
      
      const modifier = isMac ? 'Ctrl' : 'Alt';
      const tooltipText = `${modifier}+${config.key.toUpperCase()}`;
      
      element.addEventListener('mouseenter', () => {
        tooltipDiv.textContent = tooltipText;
        tooltipDiv.style.display = 'block';
        log(`Showing tooltip: ${tooltipText}`);
      });
      
      element.addEventListener('mouseleave', () => {
        tooltipDiv.style.display = 'none';
      });
      
      attachedCount++;
      log(`✓ Attached tooltip to "${config.description}": ${tooltipText}`, 'success');
    }
    
    if (attachedCount > 0 || notFoundCount > 0) {
      log(`Tooltip attachment: ${attachedCount} new, ${alreadyAttachedCount} already attached, ${notFoundCount} not found`);
    }
  }

  // Initialize
  function init() {
    log('Initialising...');
    
    if (!isContactPage()) {
      log('Not on a contact page - shortcuts inactive');
      return;
    }
    
    log('On contact page - shortcuts active');
    log(`Platform: ${isMac ? 'Mac (using Ctrl)' : 'Windows/Linux (using Alt)'}`);
    
    const modifier = isMac ? 'Ctrl' : 'Alt';
    log('Registering shortcuts:');
    for (const [name, config] of Object.entries(shortcuts)) {
      log(`  ${modifier}+${config.key.toUpperCase()} → ${config.description}`);
    }
    
    // Scan for elements on page load
    log('Scanning for target elements...');
    for (const [name, config] of Object.entries(shortcuts)) {
      const element = config.finder();
      if (element) {
        log(`  ✓ Found "${config.description}"`, 'success');
      } else {
        log(`  ✗ "${config.description}" not found (will retry when triggered)`, 'warning');
      }
    }
    
    // Setup keyboard listener
    document.addEventListener('keydown', handleKeydown, true);
    
    // Setup tooltips
    setupTooltips();
    
    log('Ready!', 'success');
  }

  // Monitor URL changes for SPA navigation
  function setupUrlMonitoring() {
    let wasOnContactPage = isContactPage();
    
    function checkUrl() {
      const nowOnContactPage = isContactPage();
      if (nowOnContactPage !== wasOnContactPage) {
        wasOnContactPage = nowOnContactPage;
        if (nowOnContactPage) {
          log('Navigated to contact page - shortcuts active');
        } else {
          log('Left contact page - shortcuts inactive');
        }
      }
    }
    
    const originalPushState = history.pushState;
    const originalReplaceState = history.replaceState;
    
    history.pushState = function(...args) {
      originalPushState.apply(this, args);
      setTimeout(checkUrl, 100);
    };
    
    history.replaceState = function(...args) {
      originalReplaceState.apply(this, args);
      setTimeout(checkUrl, 100);
    };
    
    window.addEventListener('popstate', () => setTimeout(checkUrl, 100));
    setInterval(checkUrl, 2000);
  }

  // Wait for page to be ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      init();
      setupUrlMonitoring();
    });
  } else {
    init();
    setupUrlMonitoring();
  }
})();

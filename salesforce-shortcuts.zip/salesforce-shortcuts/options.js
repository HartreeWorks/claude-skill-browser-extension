// Salesforce Contact Shortcuts - Options Page

(function() {
  'use strict';

  const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
  const modifier = isMac ? 'Ctrl' : 'Alt';

  // Update platform-specific text
  document.getElementById('platform-name').textContent = isMac ? 'Mac' : 'Windows/Linux';
  document.getElementById('platform-modifier').textContent = modifier;

  // Update all modifier keys in the UI
  document.querySelectorAll('.modifier-key').forEach(el => {
    el.textContent = modifier;
  });

  // Load saved settings
  chrome.storage.sync.get({ showTooltips: true }, (result) => {
    document.getElementById('tooltips-toggle').checked = result.showTooltips;
  });

  // Save settings when tooltip toggle changes
  document.getElementById('tooltips-toggle').addEventListener('change', (e) => {
    chrome.storage.sync.set({
      showTooltips: e.target.checked
    }, () => {
      showSaveConfirmation();
    });
  });

  // Show save confirmation
  function showSaveConfirmation() {
    const status = document.getElementById('save-status');
    status.classList.add('success');
    setTimeout(() => {
      status.classList.remove('success');
    }, 2000);
  }
})();
